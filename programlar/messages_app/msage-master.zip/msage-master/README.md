# MSAGE #
MSAGE powered by Python3\
MSAGE developed by Berkay Eren EMİN

### MSAGE nedir?
Açık kaynak kodlu, kullanıcıların kendi sunucularına veya MSAGE'in sunucularına bağlanarak yeni odalar kurup arkadaşlarıyla mesajlaştıkları bir uygulamadır. MIT Lisansı ile lisanlanmıştır. Ticari amaçlar için kullanılamaz.

İçerdiği kütüphaneler;
```
PyQt5
socket 
threading
```

NOT: Dosyalar düzenlenmeden yüklenmiştir. İçerilerinde artık kod parçaları bulunabilir.

### What is MSAGE?
It is an open source application where users can connect to their own servers or to MSAGE's servers, set up new rooms and chat with friends. Licensed with MIT License. It cannot be used for commercial purposes.

Libraries included;
```
pyqt5
socket
threading
```

NOTE: Files are uploaded without editing.


![alt text](https://github.com/Berkayerenemin/msage/blob/master/MSAGE.png)

### Tahmini gelecekte eklenecekler...
Kullanıcı profili oluşturma\
Update mekanizması\
Özel mesaj düzenlemesi\
Yeni grup oluşturma mekaniği\
Sesli konuşma\
Dosya gönderme (mp3, jpg...)

Ekleneceği düşünülen kütüphaneler;
```
sqlite3
flask
time
json
```
