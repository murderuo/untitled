# GetVideoBot
Twitter bot to download videos and gifs.
Bot can be found at https://twitter.com/GetvideoBot

How it works
1.	User finds a tweet containing a video or gif.
2.	User mentions @GetVideoBot in a reply
3.	The bot replies with a link to download the video.


This readme will be updated when i have time.
