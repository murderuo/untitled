mps_youtube.commands.config module
==================================

.. automodule:: mps_youtube.commands.config
    :members:
    :undoc-members:
    :show-inheritance:
