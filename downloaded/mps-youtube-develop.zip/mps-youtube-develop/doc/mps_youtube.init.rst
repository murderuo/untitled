mps_youtube.init module
=======================

.. automodule:: mps_youtube.init
    :members:
    :undoc-members:
    :show-inheritance:
