mps_youtube.g module
====================

.. automodule:: mps_youtube.g
    :members:
    :undoc-members:
    :show-inheritance:
