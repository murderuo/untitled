mps_youtube.playlist module
===========================

.. automodule:: mps_youtube.playlist
    :members:
    :undoc-members:
    :show-inheritance:
