mps_youtube.paths module
========================

.. automodule:: mps_youtube.paths
    :members:
    :undoc-members:
    :show-inheritance:
