mps_youtube.config module
=========================

.. automodule:: mps_youtube.config
    :members:
    :undoc-members:
    :show-inheritance:
