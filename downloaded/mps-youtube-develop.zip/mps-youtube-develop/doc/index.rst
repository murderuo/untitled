.. mps_youtube documentation master file, created by
   sphinx-quickstart on Mon Apr 18 17:35:31 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

API Documentation for mps_youtube
=================================

Contents:

.. toctree::
   mps_youtube


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

