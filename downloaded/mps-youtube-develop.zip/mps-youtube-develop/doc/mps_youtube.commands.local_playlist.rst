mps_youtube.commands.local_playlist module
==========================================

.. automodule:: mps_youtube.commands.local_playlist
    :members:
    :undoc-members:
    :show-inheritance:
