mps_youtube.helptext module
===========================

.. automodule:: mps_youtube.helptext
    :members:
    :undoc-members:
    :show-inheritance:
