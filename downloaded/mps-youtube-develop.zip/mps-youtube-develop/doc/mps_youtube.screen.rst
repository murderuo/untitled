mps_youtube.screen module
=========================

.. automodule:: mps_youtube.screen
    :members:
    :undoc-members:
    :show-inheritance:
