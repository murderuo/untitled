mps_youtube.commands.search module
==================================

.. automodule:: mps_youtube.commands.search
    :members:
    :undoc-members:
    :show-inheritance:
