__version__ = "0.2.8"
__notes__ = "released 17 February 2018"
__author__ = "np1"
__license__ = "GPLv3"
__url__ = "https://github.com/mps-youtube/mps-youtube"

from . import init
init.init()
from . import main
