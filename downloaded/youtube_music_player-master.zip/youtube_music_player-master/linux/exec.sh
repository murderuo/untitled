source env/bin/activate
cd ..
python3 ./youtubeListPlayer.py
