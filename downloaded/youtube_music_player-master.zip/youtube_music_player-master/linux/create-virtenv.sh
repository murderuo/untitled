#!/bin/bash
virtualenv -p python3 --no-site-package env
